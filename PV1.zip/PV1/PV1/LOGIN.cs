﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PV1
{
    public partial class LOGIN : Form
    {
        public LOGIN()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsuario.Text == "" || txtContra.Text == "")
            {
                MessageBox.Show("Porfavor llene los campos", " Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                var obj = new EnlaceDB();
                var TableD = new DataTable();
                TableD = obj.ODatosEmpleado("Admini", int.Parse(txtUsuario.Text), txtContra.Text, "", "", "","", DateTime.Now, "", "");

                if (TableD.Rows.Count == 0)
                {
                    MessageBox.Show("No existe ese empleado / admin", " Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    if (TableD.Rows[0][1].ToString() == "1")
                    {

                        var menu = new Menu();
                        menu.ShowDialog();

                    }
                    else
                    {
                        //string nombre = TableD.Rows[0][0].ToString();
                        //string ide = TableD.Rows[0][2].ToString();

                        //var menue = new consul(nombre, ide);
                        //menue.ShowDialog();

                    }


                }

            }
        }
    }
}
        
