﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace PV1
{
    class EnlaceDB
    {
        static private string _aux { set; get; }
        static private SqlConnection _conexion;
        static private SqlDataAdapter _adaptador = new SqlDataAdapter();
        static private SqlCommand _comandosql = new SqlCommand();
        static private DataTable _tabla = new DataTable();
        static private DataSet _DS = new DataSet();

        public DataTable obtenertabla
        {
            get
            {
                return _tabla;
            }
        }

        private static void conectar()
        {
            //string cnn = ConfigurationManager.AppSettings["desarrollo1"];
            string cnn = ConfigurationManager.ConnectionStrings["Grupo03"].ToString();
            _conexion = new SqlConnection(cnn);
            _conexion.Open();
        }

        private static void desconectar()
        {
            _conexion.Close();
        }

        public DataTable ConsultaTabla(string SP)
        {
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                conectar();
                string qry = SP;
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;

                var parametro1 = _comandosql.Parameters.Add("@Accion", SqlDbType.Char, 1);
                parametro1.Value = "W";

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return tabla;
        }

        public DataTable ConsultaTabla2(string Accion, int No_Empleado)
        {
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                conectar();
                string qry = "SPEMPLEADO";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;

                var parametro1 = _comandosql.Parameters.Add("@Accion", SqlDbType.Char, 1);
                parametro1.Value = Accion;

                var parametro2 = _comandosql.Parameters.Add("@Id_Empleado", SqlDbType.Int);
                parametro2.Value = No_Empleado;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return tabla;
        }

        //EMPLEADO
        //TRAE LOS DATOS UN EMPLEADO
        public DataTable ODatosEmpleado(string Accion, int Id_Empleado, string Contrasena, string Nombre, string Apellido_Paterno, string Apellido_Materno,
          string Curp, DateTime Fecha_Nacimiento, string Email, string No_Nomina)
        {
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                conectar();
                string qry = "SPEMPLEADO";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;

                var parametro1 = _comandosql.Parameters.Add("@Accion", SqlDbType.Char, 100);
                parametro1.Value = Accion;

                var parametro2 = _comandosql.Parameters.Add("@Id_Empleado", SqlDbType.Char, 1);
                parametro2.Value = Id_Empleado;

                var parametro3 = _comandosql.Parameters.Add("@Contrasena", SqlDbType.VarChar, 30);
                parametro3.Value = Contrasena;

                var parametro4 = _comandosql.Parameters.Add("@Nombre", SqlDbType.VarChar, 30);
                parametro4.Value = Nombre;

                var parametro5 = _comandosql.Parameters.Add("@Apellido_Paterno", SqlDbType.VarChar, 30);
                parametro5.Value = Apellido_Paterno;

                var parametro6 = _comandosql.Parameters.Add("@Apellido_Materno", SqlDbType.VarChar, 30);
                parametro6.Value = Apellido_Materno;

                var parametro7 = _comandosql.Parameters.Add("@Curp", SqlDbType.VarChar, 30);
                parametro7.Value = Curp;

                var parametro9 = _comandosql.Parameters.Add("@Fecha_Nacimiento", SqlDbType.DateTime);
                parametro9.Value = Fecha_Nacimiento;

                var parametro10 = _comandosql.Parameters.Add("@Email", SqlDbType.VarChar, 30);
                parametro10.Value = Email;

                var parametro11 = _comandosql.Parameters.Add("@No_Nomina", SqlDbType.VarChar, 30);
                parametro11.Value = No_Nomina;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return tabla;
        }
            //AGREGA, MODIFICA EMPLEADOS
        public bool Agrega_Modifica_Empleados(string Accion, int Id_Empleado, string Contrasena, 
            string Nombre, string Apellido_Paterno, string Apellido_Materno,
         string Curp, DateTime Fecha_Nacimiento, string Email, string No_Nomina, DateTime Fecha_Ingreso)
        {
            var msg = "";
            var add = true;
            try
            {
                conectar();
                string qry = "SPEMPLEADO";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;

                var parametro1 = _comandosql.Parameters.Add("@Accion", SqlDbType.Char, 100);
                parametro1.Value = Accion;

                var parametro2 = _comandosql.Parameters.Add("@Id_Empleado", SqlDbType.Int);
                parametro2.Value = Id_Empleado;


                var parametro3 = _comandosql.Parameters.Add("@Contrasena", SqlDbType.VarChar, 30);
                parametro3.Value = Contrasena;

                var parametro4 = _comandosql.Parameters.Add("@Nombre", SqlDbType.VarChar, 30);
                parametro4.Value = Nombre;

                var parametro5 = _comandosql.Parameters.Add("@Apellido_Paterno", SqlDbType.VarChar, 30);
                parametro5.Value = Apellido_Paterno;

                var parametro6 = _comandosql.Parameters.Add("@Apellido_Materno", SqlDbType.VarChar, 30);
                parametro6.Value = Apellido_Materno;

                var parametro7 = _comandosql.Parameters.Add("@Curp", SqlDbType.VarChar, 30);
                parametro7.Value = Curp;

                var parametro9 = _comandosql.Parameters.Add("@Fecha_Nacimiento", SqlDbType.DateTime);
                parametro9.Value = Fecha_Nacimiento;

                var parametro10 = _comandosql.Parameters.Add("@Email", SqlDbType.VarChar, 30);
                parametro10.Value = Email;


                var parametro11 = _comandosql.Parameters.Add("@No_Nomina", SqlDbType.VarChar, 30);
                parametro11.Value = No_Nomina;

                var parametro12 = _comandosql.Parameters.Add("@Fecha_Ingreso", SqlDbType.DateTime);
                parametro12.Value = Fecha_Ingreso;


                _adaptador.InsertCommand = _comandosql;

                _comandosql.ExecuteNonQuery();
            }
            catch (SqlException e)
            {
                add = false;
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return add;
        }


        //DEPARTAMENTOS
        public bool AgModDepas(string Accion, int IdDepaartamento, string Nombre, string Clave, 
            int PermiteDevoluciones)
        {
            var msg = "";
            var add = true;
            try
            {
                conectar();
                string qry = "SPDEPA";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;

                var parametro1 = _comandosql.Parameters.Add("@Accion", SqlDbType.Char, 100);
                parametro1.Value = Accion;

                var parametro11 = _comandosql.Parameters.Add("@IdDepaartamento", SqlDbType.Int);
                parametro11.Value = IdDepaartamento;

                var parametro2 = _comandosql.Parameters.Add("@Nombre", SqlDbType.VarChar, 20);
                parametro2.Value = Nombre;

                var parametro3 = _comandosql.Parameters.Add("@Clave", SqlDbType.VarChar, 20);
                parametro3.Value = Clave;

                var parametro4 = _comandosql.Parameters.Add("@PermiteDevoluciones", SqlDbType.Int);
                parametro4.Value = PermiteDevoluciones;


                _adaptador.InsertCommand = _comandosql;

                _comandosql.ExecuteNonQuery();
            }


            catch (SqlException e)
            {
                add = false;
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return add;
        }


    }
}
