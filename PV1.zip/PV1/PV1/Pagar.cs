﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PV1
{
    public partial class Pagar : Form
    {
        public Pagar()
        {
            InitializeComponent();
        }

        int contador=0;

        private void CBEfectivo_CheckedChanged(object sender, EventArgs e)
        {

            if (CBMPagos.Checked && CBEfectivo.Checked)
            {
                contador++;
                if (contador == 2)
                {
                    if (CBEfectivo.Checked && CBCheques.Checked)
                    {
                        CBDebito.Enabled = false;
                        CBCredito.Enabled = false;
                    }
                    else if (CBEfectivo.Checked && CBDebito.Checked) {
                        CBCheques.Enabled = false;
                        CBCredito.Enabled = false;
                    }
                    else if (CBEfectivo.Checked && CBCredito.Checked)
                    {
                        CBCheques.Enabled = false;
                        CBDebito.Enabled = false;
                    }
                }
                else
                {
                    CBCheques.Enabled = true;
                    CBDebito.Enabled = true;
                    CBCredito.Enabled = true;
                    CBMPagos.Enabled = true;
                }

            }
            else if(CBMPagos.Checked && !CBEfectivo.Checked)
            {
                contador--;
                CBCheques.Enabled = true;
                CBDebito.Enabled = true;
                CBCredito.Enabled = true;
                CBMPagos.Enabled = true;
            }
            
            else if (CBEfectivo.Checked) {
                CBCheques.Enabled = false;
                CBDebito.Enabled = false;
                CBCredito.Enabled = false;
                CBMPagos.Enabled = false;
            }
            else
            {
                CBCheques.Enabled = true;
                CBDebito.Enabled = true;
                CBCredito.Enabled = true;
                CBMPagos.Enabled = true;
               
            }
            
            
        }

        private void CBCheques_CheckedChanged(object sender, EventArgs e)
        {
            if (CBMPagos.Checked && CBCheques.Checked)
            {
                contador++;
                if (contador == 2)
                {
                    if (CBCheques.Checked && CBEfectivo.Checked)
                    {
                        CBDebito.Enabled = false;
                        CBCredito.Enabled = false;
                    }
                    else if (CBCheques.Checked && CBDebito.Checked)
                    {
                        CBEfectivo.Enabled = false;
                        CBCredito.Enabled = false;
                    }
                    else if (CBCheques.Checked && CBCredito.Checked)
                    {
                        CBEfectivo.Enabled = false;
                        CBDebito.Enabled = false;
                    }
                }
            }
            else if (CBMPagos.Checked && !CBCheques.Checked)
            {
                contador--;
                if (contador <= 2)
                {
                    CBEfectivo.Enabled = true;
                    CBDebito.Enabled = true;
                    CBCredito.Enabled = true;
                    CBMPagos.Enabled = true;
                }
            }
            else if (CBCheques.Checked)
            {
                CBEfectivo.Enabled = false;
                CBDebito.Enabled = false;
                CBCredito.Enabled = false;
                CBMPagos.Enabled = false;
            }
            else
            {
                CBEfectivo.Enabled = true;
                CBDebito.Enabled = true;
                CBCredito.Enabled = true;
                CBMPagos.Enabled = true;
            }
        }

        private void CBDebito_CheckedChanged(object sender, EventArgs e)
        {
            if (CBMPagos.Checked&&CBDebito.Checked)
            {
                contador++;
                if (contador == 2)
                {
                    if (CBDebito.Checked && CBEfectivo.Checked)
                    {
                        CBCheques.Enabled = false;
                        CBCredito.Enabled = false;
                    }
                    else if (CBDebito.Checked && CBCheques.Checked)
                    {
                        CBEfectivo.Enabled = false;
                        CBCredito.Enabled = false;
                    }
                    else if (CBDebito.Checked && CBCredito.Checked)
                    {
                        CBEfectivo.Enabled = false;
                        CBCheques.Enabled = false;
                    }
                }
            }
            else if (CBMPagos.Checked && !CBDebito.Checked)
            {
                contador--;
                CBEfectivo.Enabled = true;
                CBCredito.Enabled = true;
                CBCheques.Enabled = true;
                CBMPagos.Enabled = true;
            }
            else if (CBDebito.Checked)
            {
                CBEfectivo.Enabled = false;
                CBCredito.Enabled = false;
                CBCheques.Enabled = false;
                CBMPagos.Enabled = false;
            }
            else
            {
                CBEfectivo.Enabled = true;
                CBCredito.Enabled = true;
                CBCheques.Enabled = true;
                CBMPagos.Enabled = true;
            }

        }

        private void CBCredito_CheckedChanged(object sender, EventArgs e)
        {
            if (CBMPagos.Checked&&CBCredito.Checked)
            {
                contador++;
                if (contador == 2)
                {
                    if (CBCredito.Checked && CBEfectivo.Checked)
                    {
                        CBCheques.Enabled = false;
                        CBDebito.Enabled = false;
                    }
                    else if (CBCredito.Checked && CBCheques.Checked)
                    {
                        CBEfectivo.Enabled = false;
                        CBDebito.Enabled = false;
                    }
                    else if (CBCredito.Checked && CBDebito.Checked)
                    {
                        CBEfectivo.Enabled = false;
                        CBCheques.Enabled = false;
                    }
                }
            }
            else if (CBMPagos.Checked && !CBCredito.Checked)
            {
                contador--;
                CBEfectivo.Enabled = true;
                CBDebito.Enabled = true;
                CBCheques.Enabled = true;
                CBMPagos.Enabled = true;
            }
            else if (CBCredito.Checked){
                CBEfectivo.Enabled = false;
                CBDebito.Enabled = false;
                CBCheques.Enabled = false;
                CBMPagos.Enabled = false;
            }
            else
            {
                CBEfectivo.Enabled = true;
                CBDebito.Enabled = true;
                CBCheques.Enabled = true;
                CBMPagos.Enabled = true;
            }
        }

        private void CBMPagos_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void BtnPagar_Click(object sender, EventArgs e)
        {
            TXTotalPago.Text = "100";

            if (CBEfectivo.Checked && TxtEfectivo.Text != "")
            {


                float PagoTotal= float.Parse(TXTotalPago.Text);
                float PagoEfectivo = float.Parse(TxtEfectivo.Text);


                TxtDevolucion.Text = (PagoTotal - PagoEfectivo).ToString();

            }
        }
    }
}
