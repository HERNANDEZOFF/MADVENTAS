﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PV1
{
    public partial class CrearEmp : Form
    {
        public CrearEmp()
        {
            InitializeComponent();
        }
        private void CrearEmp_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'tERMINAL5DataSet.Empleado' Puede moverla o quitarla según sea necesario.
            this.empleadoTableAdapter.Fill(this.tERMINAL5DataSet.Empleado);
            var obj = new EnlaceDB();
            var tablita = new DataTable();
            var tablita2 = new DataTable();
            var tablita3 = new DataTable();
            tablita = obj.ConsultaTabla("SPEMPLEADO");
            dataGridView1.DataSource = tablita;

            var aynose = new EnlaceDB();
            var tab = new DataTable();

            var aynose2 = new EnlaceDB();
            var tab2 = new DataTable();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (TCont.Text == "" || Tnombre.Text == "" || TApaterno.Text == "" || TAMaterno.Text == "" || TCurp.Text == "" ||
                TCorreo.Text == "" || TXTClave.Text =="")
            {
                MessageBox.Show("Llene todos los campos", ("Aviso"), MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                var obj = new EnlaceDB();
                obj.Agrega_Modifica_Empleados("Insert", 0, TCont.Text, Tnombre.Text, TApaterno.Text, TAMaterno.Text, TCurp.Text,
                FechaNacimiento.Value, TCorreo.Text, TXTClave.Text, FechaIngreso.Value);
                MessageBox.Show("Bien", "Datos Actualizado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                var objet = new EnlaceDB();
                var Tablaemp = new DataTable();
                Tablaemp = obj.ConsultaTabla("SPEMPLEADO");
                dataGridView1.DataSource = Tablaemp;

                TCont.Text = "";
                Tnombre.Text = "";
                TApaterno.Text = "";
                TAMaterno.Text = "";
                TCurp.Text = "";
                TCorreo.Text = "";
                TXTClave.Text = "";
                FechaNacimiento.Value = DateTime.Now;
                FechaIngreso.Value = DateTime.Now;
            }

        }

        private void BTNBUSCAR_Click(object sender, EventArgs e)
        {
            if (TXTBuscar.Text == "")
            {
                MessageBox.Show("Porfavor ingrese los datos correspondientes", ("Aviso"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else

            {

                int apupu = int.Parse(TXTBuscar.Text);

                var emp = new EnlaceDB();
                var tabla = new DataTable();


                tabla = emp.ConsultaTabla2("S", apupu);
                if (tabla.Rows.Count == 0)
                {
                    MessageBox.Show("No existe ese empleado", ("Aviso"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    TCont.Text = tabla.Rows[0][1].ToString();
                    Tnombre.Text = tabla.Rows[0][2].ToString();
                    TApaterno.Text = tabla.Rows[0][3].ToString();
                    TAMaterno.Text = tabla.Rows[0][4].ToString();
                    TCurp.Text = tabla.Rows[0][5].ToString();
                    FechaNacimiento.Value = DateTime.Parse(tabla.Rows[0][6].ToString());
                    TCorreo.Text = tabla.Rows[0][7].ToString();
                    TXTClave.Text = tabla.Rows[0][8].ToString();
                    FechaIngreso.Value = DateTime.Parse(tabla.Rows[0][9].ToString());
                }
            }
        }

        private void BTNEdit_Click(object sender, EventArgs e)
        {
            if (TXTBuscar.Text == "" || TCont.Text == "" || Tnombre.Text == "" || TApaterno.Text == "" || TAMaterno.Text == "" ||
                TCurp.Text == "" || TCorreo.Text == "" || TXTClave.Text == "" )
            {
                MessageBox.Show("Llene todos los campos ", ("Aviso"), MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                int ID = int.Parse(TXTBuscar.Text);

                var obje = new EnlaceDB();

                var checar = new EnlaceDB();
                var tablaChecar = new DataTable();
                tablaChecar = checar.ConsultaTabla2("S", int.Parse(TXTBuscar.Text));

                if (tablaChecar.Rows.Count == 0)
                {
                    MessageBox.Show("No puede modificar un empleado que no existe", ("Aviso"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {

                    obje.Agrega_Modifica_Empleados("Actu", ID, TCont.Text, Tnombre.Text, TApaterno.Text, TAMaterno.Text, TCurp.Text,
                    FechaNacimiento.Value, TCorreo.Text, TXTClave.Text, FechaIngreso.Value);
                    MessageBox.Show("Bien", "Datos Actualizado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);


                    var eye = new EnlaceDB();

                    var ayeyi = new DataTable();

                    ayeyi = eye.ConsultaTabla("SPEMPLEADO");

                    dataGridView1.DataSource = ayeyi;
                }
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (TXTBuscar.Text == "")
            {
                MessageBox.Show("Ingrese el Nro. de empleado correcto", ("Aviso"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                var resp = new DialogResult();
                resp = MessageBox.Show("¿Quiere dar de baja al usuario?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (resp == DialogResult.Yes)
                {



                    int tatita = int.Parse(TXTBuscar.Text);

                    var Depa = new EnlaceDB();
                    var tabla = new DataTable();

                    var checar = new EnlaceDB();
                    var tablaChecar = new DataTable();
                    tablaChecar = checar.ConsultaTabla2("S", int.Parse(TXTBuscar.Text));

                    if (tablaChecar.Rows.Count == 0)
                    {
                        MessageBox.Show("No puede dar de baja un empleado que no existe", ("Aviso"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }



                    else
                    {


                        tabla = Depa.ConsultaTabla2("B", tatita);

                        var eye = new EnlaceDB();

                        var ayeyi = new DataTable();

                        ayeyi = eye.ConsultaTabla("SPEMPLEADO");

                        dataGridView1.DataSource = ayeyi;

                        MessageBox.Show("Empleado dado de bajo", ("Aviso"), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (TXTBuscar.Text == "")
            {
                MessageBox.Show("Ingrese el Nro. de empleado correcto", ("Aviso"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                var resp = new DialogResult();
                resp = MessageBox.Show("Desea reactivar al empleado", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (resp == DialogResult.Yes)
                {



                    int tatita = int.Parse(TXTBuscar.Text);

                    var Depa = new EnlaceDB();
                    var tabla = new DataTable();

                    tabla = Depa.ConsultaTabla2("R", tatita);



                    var eye = new EnlaceDB();

                    var ayeyi = new DataTable();

                    ayeyi = eye.ConsultaTabla("SPEMPLEADO");

                    dataGridView1.DataSource = ayeyi;

                    MessageBox.Show("Empleado Reactivado", ("Aviso"), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }
    }
}
