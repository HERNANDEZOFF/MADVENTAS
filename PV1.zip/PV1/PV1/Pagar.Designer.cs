﻿
namespace PV1
{
    partial class Pagar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.TXTotalPago = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtDevolucion = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TxtEfectivo = new System.Windows.Forms.TextBox();
            this.TxtDebito = new System.Windows.Forms.TextBox();
            this.TxtCredito = new System.Windows.Forms.TextBox();
            this.TxtCheque = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.BtnPagar = new System.Windows.Forms.Button();
            this.CBEfectivo = new System.Windows.Forms.CheckBox();
            this.CBCheques = new System.Windows.Forms.CheckBox();
            this.CBDebito = new System.Windows.Forms.CheckBox();
            this.CBCredito = new System.Windows.Forms.CheckBox();
            this.CBMPagos = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(383, 160);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 45);
            this.button1.TabIndex = 0;
            this.button1.Text = "Imprimir ticket";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Formas de pago";
            // 
            // TXTotalPago
            // 
            this.TXTotalPago.Location = new System.Drawing.Point(65, 101);
            this.TXTotalPago.Name = "TXTotalPago";
            this.TXTotalPago.ReadOnly = true;
            this.TXTotalPago.Size = new System.Drawing.Size(100, 22);
            this.TXTotalPago.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "$";
            // 
            // TxtDevolucion
            // 
            this.TxtDevolucion.Location = new System.Drawing.Point(211, 101);
            this.TxtDevolucion.Name = "TxtDevolucion";
            this.TxtDevolucion.ReadOnly = true;
            this.TxtDevolucion.Size = new System.Drawing.Size(100, 22);
            this.TxtDevolucion.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(69, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "Total a pagar";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(219, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Devolucion";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(62, 188);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "Pago en efetivo:";
            // 
            // TxtEfectivo
            // 
            this.TxtEfectivo.Location = new System.Drawing.Point(65, 223);
            this.TxtEfectivo.Name = "TxtEfectivo";
            this.TxtEfectivo.Size = new System.Drawing.Size(100, 22);
            this.TxtEfectivo.TabIndex = 10;
            // 
            // TxtDebito
            // 
            this.TxtDebito.Location = new System.Drawing.Point(65, 309);
            this.TxtDebito.Name = "TxtDebito";
            this.TxtDebito.Size = new System.Drawing.Size(100, 22);
            this.TxtDebito.TabIndex = 12;
            // 
            // TxtCredito
            // 
            this.TxtCredito.Location = new System.Drawing.Point(220, 309);
            this.TxtCredito.Name = "TxtCredito";
            this.TxtCredito.Size = new System.Drawing.Size(100, 22);
            this.TxtCredito.TabIndex = 14;
            // 
            // TxtCheque
            // 
            this.TxtCheque.Location = new System.Drawing.Point(220, 223);
            this.TxtCheque.Name = "TxtCheque";
            this.TxtCheque.Size = new System.Drawing.Size(100, 22);
            this.TxtCheque.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(217, 188);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(130, 17);
            this.label6.TabIndex = 16;
            this.label6.Text = "Pago con cheques:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(102, 385);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(195, 17);
            this.label7.TabIndex = 19;
            this.label7.Text = "Limitado a 2 formas de pagos";
            // 
            // BtnPagar
            // 
            this.BtnPagar.Location = new System.Drawing.Point(383, 244);
            this.BtnPagar.Name = "BtnPagar";
            this.BtnPagar.Size = new System.Drawing.Size(107, 45);
            this.BtnPagar.TabIndex = 20;
            this.BtnPagar.Text = "Pagar";
            this.BtnPagar.UseVisualStyleBackColor = true;
            this.BtnPagar.Click += new System.EventHandler(this.BtnPagar_Click);
            // 
            // CBEfectivo
            // 
            this.CBEfectivo.AutoSize = true;
            this.CBEfectivo.Location = new System.Drawing.Point(46, 160);
            this.CBEfectivo.Name = "CBEfectivo";
            this.CBEfectivo.Size = new System.Drawing.Size(80, 21);
            this.CBEfectivo.TabIndex = 21;
            this.CBEfectivo.Text = "Efectivo";
            this.CBEfectivo.UseVisualStyleBackColor = true;
            this.CBEfectivo.CheckedChanged += new System.EventHandler(this.CBEfectivo_CheckedChanged);
            // 
            // CBCheques
            // 
            this.CBCheques.AutoSize = true;
            this.CBCheques.Location = new System.Drawing.Point(201, 160);
            this.CBCheques.Name = "CBCheques";
            this.CBCheques.Size = new System.Drawing.Size(86, 21);
            this.CBCheques.TabIndex = 22;
            this.CBCheques.Text = "Cheques";
            this.CBCheques.UseVisualStyleBackColor = true;
            this.CBCheques.CheckedChanged += new System.EventHandler(this.CBCheques_CheckedChanged);
            // 
            // CBDebito
            // 
            this.CBDebito.AutoSize = true;
            this.CBDebito.Location = new System.Drawing.Point(46, 269);
            this.CBDebito.Name = "CBDebito";
            this.CBDebito.Size = new System.Drawing.Size(140, 21);
            this.CBDebito.TabIndex = 23;
            this.CBDebito.Text = "Tarjeta de Debito";
            this.CBDebito.UseVisualStyleBackColor = true;
            this.CBDebito.CheckedChanged += new System.EventHandler(this.CBDebito_CheckedChanged);
            // 
            // CBCredito
            // 
            this.CBCredito.AutoSize = true;
            this.CBCredito.Location = new System.Drawing.Point(201, 269);
            this.CBCredito.Name = "CBCredito";
            this.CBCredito.Size = new System.Drawing.Size(144, 21);
            this.CBCredito.TabIndex = 24;
            this.CBCredito.Text = "Tarjeta de Credito";
            this.CBCredito.UseVisualStyleBackColor = true;
            this.CBCredito.CheckedChanged += new System.EventHandler(this.CBCredito_CheckedChanged);
            // 
            // CBMPagos
            // 
            this.CBMPagos.AutoSize = true;
            this.CBMPagos.Location = new System.Drawing.Point(131, 361);
            this.CBMPagos.Name = "CBMPagos";
            this.CBMPagos.Size = new System.Drawing.Size(128, 21);
            this.CBMPagos.TabIndex = 25;
            this.CBMPagos.Text = "Multiples pagos";
            this.CBMPagos.UseVisualStyleBackColor = true;
            this.CBMPagos.CheckedChanged += new System.EventHandler(this.CBMPagos_CheckedChanged);
            // 
            // Pagar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 450);
            this.Controls.Add(this.CBMPagos);
            this.Controls.Add(this.CBCredito);
            this.Controls.Add(this.CBDebito);
            this.Controls.Add(this.CBCheques);
            this.Controls.Add(this.CBEfectivo);
            this.Controls.Add(this.BtnPagar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TxtCheque);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.TxtCredito);
            this.Controls.Add(this.TxtDebito);
            this.Controls.Add(this.TxtEfectivo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TxtDevolucion);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TXTotalPago);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Pagar";
            this.Text = "z";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TXTotalPago;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TxtDevolucion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TxtEfectivo;
        private System.Windows.Forms.TextBox TxtDebito;
        private System.Windows.Forms.TextBox TxtCredito;
        private System.Windows.Forms.TextBox TxtCheque;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button BtnPagar;
        private System.Windows.Forms.CheckBox CBEfectivo;
        private System.Windows.Forms.CheckBox CBCheques;
        private System.Windows.Forms.CheckBox CBDebito;
        private System.Windows.Forms.CheckBox CBCredito;
        private System.Windows.Forms.CheckBox CBMPagos;
    }
}