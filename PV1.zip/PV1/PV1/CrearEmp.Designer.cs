﻿
namespace PV1
{
    partial class CrearEmp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.TXTBuscar = new System.Windows.Forms.TextBox();
            this.Tnombre = new System.Windows.Forms.TextBox();
            this.TApaterno = new System.Windows.Forms.TextBox();
            this.TAMaterno = new System.Windows.Forms.TextBox();
            this.TCurp = new System.Windows.Forms.TextBox();
            this.TCorreo = new System.Windows.Forms.TextBox();
            this.TXTClave = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.FechaNacimiento = new System.Windows.Forms.DateTimePicker();
            this.FechaIngreso = new System.Windows.Forms.DateTimePicker();
            this.BTNBUSCAR = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.BTNEdit = new System.Windows.Forms.Button();
            this.BtnEliminar = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.TCont = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tERMINAL5DataSet = new PV1.TERMINAL5DataSet();
            this.empleadoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.empleadoTableAdapter = new PV1.TERMINAL5DataSetTableAdapters.EmpleadoTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tERMINAL5DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.empleadoBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nro. de Empleado";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "A. Paterno:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "A. Materno:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 192);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "CURP:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(346, 156);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "F. Nacimiento:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(346, 195);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "F. Ingreso:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(34, 229);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 17);
            this.label8.TabIndex = 7;
            this.label8.Text = "Correo:";
            // 
            // TXTBuscar
            // 
            this.TXTBuscar.Location = new System.Drawing.Point(172, 34);
            this.TXTBuscar.Name = "TXTBuscar";
            this.TXTBuscar.Size = new System.Drawing.Size(144, 22);
            this.TXTBuscar.TabIndex = 8;
            // 
            // Tnombre
            // 
            this.Tnombre.Location = new System.Drawing.Point(172, 81);
            this.Tnombre.Name = "Tnombre";
            this.Tnombre.Size = new System.Drawing.Size(144, 22);
            this.Tnombre.TabIndex = 9;
            // 
            // TApaterno
            // 
            this.TApaterno.Location = new System.Drawing.Point(172, 116);
            this.TApaterno.Name = "TApaterno";
            this.TApaterno.Size = new System.Drawing.Size(144, 22);
            this.TApaterno.TabIndex = 10;
            // 
            // TAMaterno
            // 
            this.TAMaterno.Location = new System.Drawing.Point(172, 153);
            this.TAMaterno.Name = "TAMaterno";
            this.TAMaterno.Size = new System.Drawing.Size(144, 22);
            this.TAMaterno.TabIndex = 11;
            // 
            // TCurp
            // 
            this.TCurp.Location = new System.Drawing.Point(172, 190);
            this.TCurp.Name = "TCurp";
            this.TCurp.Size = new System.Drawing.Size(144, 22);
            this.TCurp.TabIndex = 12;
            // 
            // TCorreo
            // 
            this.TCorreo.Location = new System.Drawing.Point(172, 229);
            this.TCorreo.Name = "TCorreo";
            this.TCorreo.Size = new System.Drawing.Size(144, 22);
            this.TCorreo.TabIndex = 13;
            // 
            // TXTClave
            // 
            this.TXTClave.Location = new System.Drawing.Point(482, 116);
            this.TXTClave.Name = "TXTClave";
            this.TXTClave.Size = new System.Drawing.Size(144, 22);
            this.TXTClave.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(344, 119);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 17);
            this.label9.TabIndex = 15;
            this.label9.Text = "Clave Usuario:";
            // 
            // FechaNacimiento
            // 
            this.FechaNacimiento.Location = new System.Drawing.Point(484, 156);
            this.FechaNacimiento.MaxDate = new System.DateTime(2529, 12, 1, 0, 0, 0, 0);
            this.FechaNacimiento.MinDate = new System.DateTime(1930, 1, 1, 0, 0, 0, 0);
            this.FechaNacimiento.Name = "FechaNacimiento";
            this.FechaNacimiento.Size = new System.Drawing.Size(254, 22);
            this.FechaNacimiento.TabIndex = 16;
            this.FechaNacimiento.Value = new System.DateTime(2004, 12, 31, 0, 0, 0, 0);
            // 
            // FechaIngreso
            // 
            this.FechaIngreso.Location = new System.Drawing.Point(484, 190);
            this.FechaIngreso.MaxDate = new System.DateTime(2030, 12, 31, 0, 0, 0, 0);
            this.FechaIngreso.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.FechaIngreso.Name = "FechaIngreso";
            this.FechaIngreso.Size = new System.Drawing.Size(254, 22);
            this.FechaIngreso.TabIndex = 17;
            this.FechaIngreso.Value = new System.DateTime(2004, 12, 31, 0, 0, 0, 0);
            // 
            // BTNBUSCAR
            // 
            this.BTNBUSCAR.Location = new System.Drawing.Point(346, 27);
            this.BTNBUSCAR.Name = "BTNBUSCAR";
            this.BTNBUSCAR.Size = new System.Drawing.Size(98, 36);
            this.BTNBUSCAR.TabIndex = 18;
            this.BTNBUSCAR.Text = "Buscar";
            this.BTNBUSCAR.UseVisualStyleBackColor = true;
            this.BTNBUSCAR.Click += new System.EventHandler(this.BTNBUSCAR_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(81, 269);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(105, 38);
            this.button2.TabIndex = 19;
            this.button2.Text = "Agregar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // BTNEdit
            // 
            this.BTNEdit.Location = new System.Drawing.Point(248, 269);
            this.BTNEdit.Name = "BTNEdit";
            this.BTNEdit.Size = new System.Drawing.Size(105, 38);
            this.BTNEdit.TabIndex = 20;
            this.BTNEdit.Text = "Editar";
            this.BTNEdit.UseVisualStyleBackColor = true;
            this.BTNEdit.Click += new System.EventHandler(this.BTNEdit_Click);
            // 
            // BtnEliminar
            // 
            this.BtnEliminar.Location = new System.Drawing.Point(398, 269);
            this.BtnEliminar.Name = "BtnEliminar";
            this.BtnEliminar.Size = new System.Drawing.Size(105, 38);
            this.BtnEliminar.TabIndex = 21;
            this.BtnEliminar.Text = "Desactivar";
            this.BtnEliminar.UseVisualStyleBackColor = true;
            this.BtnEliminar.Click += new System.EventHandler(this.BtnEliminar_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(570, 269);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(104, 38);
            this.button5.TabIndex = 22;
            this.button5.Text = "Reactivar";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(346, 81);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 17);
            this.label10.TabIndex = 23;
            this.label10.Text = "Contraseña:";
            // 
            // TCont
            // 
            this.TCont.Location = new System.Drawing.Point(482, 81);
            this.TCont.Name = "TCont";
            this.TCont.Size = new System.Drawing.Size(144, 22);
            this.TCont.TabIndex = 24;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(26, 357);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(744, 244);
            this.dataGridView1.TabIndex = 25;
            // 
            // tERMINAL5DataSet
            // 
            this.tERMINAL5DataSet.DataSetName = "TERMINAL5DataSet";
            this.tERMINAL5DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // empleadoBindingSource
            // 
            this.empleadoBindingSource.DataMember = "Empleado";
            this.empleadoBindingSource.DataSource = this.tERMINAL5DataSet;
            // 
            // empleadoTableAdapter
            // 
            this.empleadoTableAdapter.ClearBeforeFill = true;
            // 
            // CrearEmp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 633);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.TCont);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.BtnEliminar);
            this.Controls.Add(this.BTNEdit);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.BTNBUSCAR);
            this.Controls.Add(this.FechaIngreso);
            this.Controls.Add(this.FechaNacimiento);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.TXTClave);
            this.Controls.Add(this.TCorreo);
            this.Controls.Add(this.TCurp);
            this.Controls.Add(this.TAMaterno);
            this.Controls.Add(this.TApaterno);
            this.Controls.Add(this.Tnombre);
            this.Controls.Add(this.TXTBuscar);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "CrearEmp";
            this.Text = "CrearEmp";
            this.Load += new System.EventHandler(this.CrearEmp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tERMINAL5DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.empleadoBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TXTBuscar;
        private System.Windows.Forms.TextBox Tnombre;
        private System.Windows.Forms.TextBox TApaterno;
        private System.Windows.Forms.TextBox TAMaterno;
        private System.Windows.Forms.TextBox TCurp;
        private System.Windows.Forms.TextBox TCorreo;
        private System.Windows.Forms.TextBox TXTClave;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker FechaNacimiento;
        private System.Windows.Forms.DateTimePicker FechaIngreso;
        private System.Windows.Forms.Button BTNBUSCAR;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button BTNEdit;
        private System.Windows.Forms.Button BtnEliminar;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox TCont;
        private System.Windows.Forms.DataGridView dataGridView1;
        private TERMINAL5DataSet tERMINAL5DataSet;
        private System.Windows.Forms.BindingSource empleadoBindingSource;
        private TERMINAL5DataSetTableAdapters.EmpleadoTableAdapter empleadoTableAdapter;
    }
}