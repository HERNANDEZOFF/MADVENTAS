﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PV1
{
    public partial class Ventana_Admin : Form
    {
        public Ventana_Admin()
        {
            InitializeComponent();
        }

        private void CREmpleado_Click(object sender, EventArgs e)
        {
            var CEMPLEADO = new CrearEmp();
            CEMPLEADO.ShowDialog();
        }

    }
}
