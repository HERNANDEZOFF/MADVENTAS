﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PV1
{
    public partial class Productos : Form
    {
        public Productos()
        {
            InitializeComponent();
        }

        private void Productos_Load(object sender, EventArgs e)
        {
            var obj = new EnlaceDB();
            var tablet = new DataTable();
            tablet = obj.ConsultaTabla("SPDEPA");


            dataGridView2.DataSource = tablet;
        }
        //DEPARTAMENTOS
        private void button7_Click(object sender, EventArgs e)
        {
            if (TxtNomDepa.Text==""||TxtClave.Text==""||TxtDevo.Text=="")
            {
                MessageBox.Show("Llene todos los campos", ("Aviso"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                var obj = new EnlaceDB();
                obj.AgModDepas("Insert",0,TxtNomDepa.Text,TxtClave.Text,0);
                MessageBox.Show("Bien", "Datos Actualizado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                var objet = new EnlaceDB();
                var Tablaemp = new DataTable();
                Tablaemp = obj.ConsultaTabla("SPDEPA");
                dataGridView2.DataSource = Tablaemp;

            }

        }
    }
}
